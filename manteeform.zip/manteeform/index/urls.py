from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.login),
    path('register',views.register),
    path('indexpage',views.indexpage),
    path('userinfo',views.user_info),
    path('performance',views.performance)
]