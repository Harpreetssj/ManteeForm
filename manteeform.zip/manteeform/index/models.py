from django.db import models
# Create your models here.

class Student_personal(models.Model):
    session = models.CharField(max_length=12)
    img = models.ImageField(upload_to='pics/')
    clas = models.CharField(max_length=15)
    semester = models.CharField(max_length=15)
    f_name = models.CharField(max_length=15)
    l_name = models.CharField(max_length=15)
    rollno = models.IntegerField(primary_key=True)
    dob = models.DateField()
    gender=models.CharField(max_length=7)
    bloodgroup = models.CharField(max_length=4)
    nationality = models.CharField(max_length=20)
    email = models.EmailField(max_length=254)
    contact = models.CharField(max_length=15)
    passport_no = models.CharField(max_length=20)
    country_coordinator_fname = models.CharField(max_length=40)
    country_coordinator_lname = models.CharField(max_length=40)
    visa_exp = models.DateField()
    father_fname = models.CharField(max_length=15)
    father_lname = models.CharField(max_length=15)
    father_contact = models.CharField(max_length=15)
    mother_fname = models.CharField(max_length=15)
    mother_lname = models.CharField(max_length=15)
    mother_contact = models.CharField(max_length=15)
    sponsored_agency = models.CharField(max_length=100)
    agency_person = models.CharField(max_length=20)
    agency_contact = models.CharField(max_length=15)
    agency_email = models.EmailField(max_length=150)
    permanent_address = models.TextField(max_length=200)
    local_address = models.TextField(max_length=200)



class Student_subjects(models.Model):
    student = models.ForeignKey(to=Student_personal, related_name="subjects",on_delete=models.CASCADE)
    subject =  models.CharField(max_length=15)

class Student_performance(models.Model):
     subject = models.ForeignKey(Student_subjects, on_delete=models.CASCADE)
     firts_session_attendence = models.IntegerField()
     firts_session_marks = models.IntegerField()
     second_session_attendence = models.IntegerField()
     second_session_marks = models.IntegerField()
