from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.http.response import HttpResponse
from django.contrib import messages
from .models import Student_personal,Student_subjects
import csv
# Create your views here.

def performance(request):
    if request.method=='POST':
        for x in request.FILES['csvfile']:
            print(x)
        #file_reader = request.FILES['csvfile']
        file_data = file_reader.read().decode('UTF-8')
        lines = file_data.split("\n")
        for row in lines:
            print(row[0])
        return redirect('/')
    else:
        return render(request,'student_performance.html')

def indexpage(request):
    if request.method=='POST':
        print('index page')
        student_object = Student_personal()
        student_object.session=request.POST['session']
        student_object.img = request.POST['img'] 
        if request.POST['rollno'] != request.user.username:
            return render(request,'mentiform.html')
        student_object.rollno = request.POST['rollno']
        student_object.f_name = request.POST['f_name']
        student_object.l_name = request.POST['l_name']
        student_object.clas = request.POST['class']
        student_object.semester = request.POST['semester']
        student_object.dob = request.POST['dob']
        student_object.gender = request.POST['gender']
        student_object.bloodgroup = request.POST['bloodgroup']
        student_object.nationality = request.POST['country']
        student_object.email = request.POST['email']
        student_object.contact = request.POST['contact']
        student_object.country_coordinator_fname = request.POST['cordinator_fname']
        student_object.country_coordinator_lname = request.POST['cordinator_lname']
        student_object.passport_no = request.POST['passport_no']
        student_object.visa_exp  = request.POST['visa_exp']
        student_object.father_fname = request.POST['father_fname']
        student_object.father_lname = request.POST['father_lname']
        student_object.father_contact = request.POST['father_contact']
        student_object.mother_fname = request.POST['mother_fname']
        student_object.mother_lname = request.POST['mother_lname']
        student_object.mother_contact = request.POST['mother_contact']
        student_object.sponsored_agency = request.POST['sponsored_agency']
        student_object.agency_person = request.POST['agency_person']
        student_object.agency_contact = request.POST['agency_contact']
        student_object.agency_email = request.POST['agency_email']
        student_object.local_address =  request.POST['local_address']
        student_object.permanent_address = request.POST['permanent_address']
        print('before save')
        student_object.save()
        print('after save')
        return redirect('/')
    else:
        if Student_personal.objects.filter(rollno=str(request.user)).exists():#check if rollno already exist
                    return redirect('/userinfo')
        return render(request,'mentiform.html')

def login(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return redirect('/admin')
        else:
            return redirect('/indexpage')

    if request.method=='POST':
        # user_type = request.POST.get('Login')

        username= request.POST['username']
        password = request.POST['password']
        try:
            user = auth.authenticate(username=username,password=password)
            if user is None:
                raise Exception
        except:
            messages.info(request,'INVALID CREDENTIALS')
            return redirect('/')

        user = auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)

        if request.user.is_staff:
            if user is not None:
                return redirect('/admin')

        else:
            if user is not None:
                print(username)
                if Student_personal.objects.filter(rollno=username).exists():#check if rollno already exist
                    return redirect('/userinfo')
                else:
                    return redirect('/indexpage')

    else:
        return render(request,'login.html')


def register(request):
    if request.method=='POST':
                first_name = request.POST['first_name']
                last_name = request.POST['last_name']
                user_name = request.POST['user_name']
                email = request.POST['email']
                password1 = request.POST['password1']
                password2 = request.POST['password2']
                if password1==password2:
                    if User.objects.filter(username=user_name).exists():
                            messages.info(request,'username Already Taken')
                            return redirect('/register')
                    elif User.objects.filter(email=email).exists():
                        messages.info(request,'Email Already Taken')
                        return redirect('/register')
                    else:
                            user = User.objects.create_user(username=user_name, password=password1,first_name=first_name, last_name=last_name, email=email)#creating User
                            return redirect('/')
                else:
                    messages.info(request,'password not Matching')
                    return redirect('/register')
                    return redirect('/register')#if passwords not matching
    else:
        return render(request,'registration.html')


def user_info(request):
    print(request.user)
    student = Student_personal.objects.all()
    for s in student:
        print(s.img.url)
    return render(request,'user_info.html',{'student':student})

