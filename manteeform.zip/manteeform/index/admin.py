from django.contrib import admin
from .models import Student_personal,Student_subjects,Student_performance
# Register your models here.

admin.site.register(Student_personal)
admin.site.register(Student_subjects)
admin.site.register(Student_performance)
